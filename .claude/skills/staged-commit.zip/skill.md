# Staged Commit Message Generator

Git staged 파일의 diff를 분석하여 구조화된 커밋 메시지를 자동 생성하는 스킬입니다.

## 사용법

```
/staged-commit
```

## 커밋 메시지 형식

```
HEADER : 메인 커밋 메시지

- (파일상대경로) : 파일별 변경 요약
- (파일상대경로) : 파일별 변경 요약
```

### 헤더 종류

| 헤더 | 의미 |
|------|------|
| `FEAT` | 새 기능 |
| `FIX` | 버그 수정 |
| `BUGFIX` | 심각한 버그 수정 |
| `ADD` | 새 파일/모듈 추가 |
| `REFACTOR` | 구조 개선 |
| `PERF` | 성능 최적화 |
| `DOCS` | 문서 변경 |
| `STYLE` | 포맷팅 |
| `CHORE` | 빌드/설정 |

## 실행 흐름

```
/staged-commit
    ↓
1. git diff --cached (staged diff 분석 — 파일 목록 + 상태 + 변경 내용)
    ↓
2. 헤더 결정 + 메인 메시지 + 파일별 메시지 생성
    ↓
3. 코드 블록으로 출력
    ↓
(--commit 옵션 시) 확인 후 git commit 실행
```

## 옵션

- `--lang=en` : 영문 커밋 메시지
- `--commit` : 생성 후 바로 커밋 실행

## 예제

```
FEAT : 세션 보안 강화 (서버 세션 검증, 계정 잠금, 로그아웃 개선)

- (platform/app/src/routes/Login/Login.tsx) : 계정 잠금 UI 통합 (카운트다운, 경고 메시지, 버튼 비활성화)
- (platform/app/src/utils/loginLockout.ts) : 계정 잠금 유틸리티 신규 생성 (5회 실패/30분 잠금)
- (platform/app/src/utils/sessionValidator.ts) : 서버 세션 검증 중앙화 유틸리티 신규 생성
```
